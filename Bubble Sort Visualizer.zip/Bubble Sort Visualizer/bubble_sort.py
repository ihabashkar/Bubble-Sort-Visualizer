"""
Ihab Ashkar
17 May 2024 5:00 p.m.
Bubble Sort Visualizer 
This project intends to create a visualization of bubble 
sort using the library, Pygame. Bubble sort is good for sorting small lists,
taking two indices and checking for the higher value, putting the lower value
first. Ultimately, the list will be displayed from least to greatest.
"""
# Importing necessary libraries
import pygame
import sys
import random

# Initializing Pygame
pygame.init()

pygame.init()

# Setting up screen dimensions
WIDTH = 800
HEIGHT = 600

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Bubble Sort Visualizer")

# Clock to track the time of the sort
clock = pygame.time.Clock()

# Setting colors for various elements
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Color for bars
BAR_COLOR = (200, 50, 50)

# Generates a list of random numbers for the program to visualize
# Returns 10 numbers from 1-100
def generate_random_numbers(n):
    return [random.randint(1, 100) for _ in range(n)]

numbers = generate_random_numbers(10)

# Creating a function to draw the bars that separate and represent the numbers
def draw_bars(numbers):
    bar_width = WIDTH // len(numbers)
    for i, num in enumerate(numbers):
        x = i * bar_width
        y = HEIGHT - num * 10  # Adjust scale factor as needed
        pygame.draw.rect(screen, BAR_COLOR, (x, y, bar_width, HEIGHT - y))

# Implementing the bubble sort, checking if the first index (0), is greater than the second
def bubble_sort(numbers):
    n = len(numbers)
    for i in range(n):
        for j in range(0, n-i-1):
            if numbers[j] > numbers[j+1]:
                numbers[j], numbers[j+1] = numbers[j+1], numbers[j]

# Creating a loop to run through the bubble sort and update the screen when it is sorted
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    screen.fill(WHITE)

    draw_bars(numbers)

    bubble_sort(numbers)

    pygame.display.flip()
    clock.tick(60)  # Limit frame rate

# The program does not effectively represent the visualization.
# Seems to be stuck on a single frame of a sorted list.
# Does not show the process of the list being sorted through a bubble sort.
